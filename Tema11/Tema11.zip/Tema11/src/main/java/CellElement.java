public interface CellElement {

    String toCharacter();

}
