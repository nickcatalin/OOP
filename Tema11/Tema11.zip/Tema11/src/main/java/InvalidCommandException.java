public class InvalidCommandException {

    public static void throwException() throws Exception {
        throw new Exception(" InvalidCommandException");
    }

}
