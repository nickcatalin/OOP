public interface Potion {

     void usePotion(Character character);
     int potionPrice();
     int regenValue();
     int potionWeight();
     String toString();
}
